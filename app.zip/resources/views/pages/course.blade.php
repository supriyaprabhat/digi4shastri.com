@extends('layouts.base')

@section('title')
    Digi4shastri
@endsection


@section('contents')

    @include('pages.inc.courseSec1')
    @include('pages.inc.courseSec2')
    @include('pages.inc.courseSec3')
    @include('pages.inc.courseSec4')
    @include('pages.inc.courseSec5')
    @include('pages.inc.courseSec6')
    {{-- @include('pages.inc.courseSec7') --}}
    @include('pages.inc.courseSec8')
    @include('pages.inc.courseSec9')
    @include('pages.inc.courseSec10')
    @include('pages.inc.courseSec11')
    
@endsection
