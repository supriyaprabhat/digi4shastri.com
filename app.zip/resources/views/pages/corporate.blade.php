@extends('layouts.base')

@section('title') 
    Corporate - Digi4shastri
@endsection


@section('contents')
   
    @include('pages.inc.corporateSec1')
    @include('pages.inc.corporateSec2')
    @include('pages.inc.corporateSec3')
    @include('pages.inc.corporateSec4')
    @include('pages.inc.corporateSec5')
    @include('pages.inc.corporateSec6')
    @include('pages.inc.corporateSec8')
    @include('pages.inc.corporateSec9')
    @include('pages.inc.corporateSec10')
    @include('pages.inc.corporateSec11')
    
@endsection