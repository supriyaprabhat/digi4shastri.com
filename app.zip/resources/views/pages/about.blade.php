@extends('layouts.base')

@section('title')
    About Digi4shastri
@endsection

@section('contents')
    @include('pages.inc.aboutSec1')
    @include('pages.inc.aboutSec2')
    @include('pages.inc.aboutSec3')
    @include('pages.inc.aboutSec4')
    @include('pages.inc.aboutSec5')
    @include('pages.inc.aboutSec6')
    @include('pages.inc.aboutSec7')
    @include('pages.inc.aboutSec8')
    @include('pages.inc.aboutSec9')
    @include('pages.inc.aboutSec10')
@endsection