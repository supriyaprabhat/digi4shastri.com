<section class="md:p-20 flex flex-col items-center p-7 lg:px-28 bg-img"
    style="background-image: url(images/about/bg2.png);">
    <h4 class="text-white font-medium md:text-3xl md:mb-14 mb-8 text-2xl text-center">Ready to kickstart your career
        in Digital? Find out what IIDE has to offer.</h4>
    <a href="" class="btn-p !mx-auto !px-8 cursor-pointer ">Know More</a>
</section>