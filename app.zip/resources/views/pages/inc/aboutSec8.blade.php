<section class="md:p-20 flex flex-col items-center p-7 lg:px-28 bg-main2">
    <h4 class="text-white font-medium md:text-3xl mb-5 text-2xl text-center">Your Future in Digital Marketing Starts
        Here</h4>
    <h4 class=" md:text-3xl md:mb-14 mb-8 text-2xl text-center">Talk to counsellor & get guided in your digital
        marketing journey</h4>
    <a href="" class="btn-p !mx-auto !px-8 cursor-pointer ">Schedule Appointment</a>
</section>