<?php

namespace App\Filament\Resources\CareerCounsellingResource\Pages;

use App\Filament\Resources\CareerCounsellingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCareerCounselling extends CreateRecord
{
    protected static string $resource = CareerCounsellingResource::class;
}
