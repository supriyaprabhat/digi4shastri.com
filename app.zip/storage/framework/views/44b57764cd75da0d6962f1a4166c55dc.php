<?php if(!empty($sections[1])): ?>
    <?php
        $wcSection = $sections[1];
    ?>

    <?php if($wcSection->status == 1): ?>
        <!-- why choose section2-->
        <section class="flex flex-col items-center text-center gap-y-5 sm:p-20 px-6 py-11 bg-grid">
            <img src="<?php echo e(asset('storage/' . $wcSection->image)); ?>" alt="">
            <h3 class="text-2xl font-bold "><?php echo e($wcSection->sub_heading1); ?></h3>
            <h2 class="text-red-700 font-semibold text-4xl"><?php echo e($wcSection->heading); ?></h2>
            <p class="text-xl max-w-2xl"><?php echo e($wcSection->sub_heading2); ?></p>
        </section>
    <?php endif; ?>
<?php endif; ?><?php /**PATH D:\laravel\digi\resources\views/pages/inc/wcSection.blade.php ENDPATH**/ ?>