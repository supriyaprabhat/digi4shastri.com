<?php if(!empty($sections[9])): ?>
    <?php
        $sec = $sections[9];
    ?>

    <?php if($sec->status == 1): ?>
    <!-- section11 faqs -->
        <section class="md:p-20 p-7 lg:px-28">
            <!-- FAQ  -->
            <div class="mb-11">
                <h4 class="text-3xl sm:text-5xl text-red-600 font-bold"><?php echo e($sec->heading); ?></h4>
            </div>
            <div class="faq ">
                <?php $__currentLoopData = $sec->other1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="<?php echo e($i == 0 ? 'active' : ''); ?> faq-item p-4 mb-3 shadow-xl">
                        <div class="question">
                            <h3 class="text-xl font-bold">
                                <?php echo e($item['text1']); ?>

                            </h3>
                            <i class="fa-solid fa-circle-chevron-down"></i>
                        </div>
                        <div class="answer">
                            <hr class="my-3" />
                            <?php echo e($item['text2']); ?>

                            <br />
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>
<?php endif; ?><?php /**PATH D:\laravel\digi\resources\views/pages/inc/corporateSec11.blade.php ENDPATH**/ ?>