<!-- section9 testimonials -->
<?php if(!empty($sections[6])): ?>
    <?php
        $tSection = $sections[6];
    ?>
    <section>
        <div class="md:p-20 p-6">
            <h2 class="text-red-700 font-semibold text-4xl md:text-5xl "><?php echo e($tSection->heading); ?></h2>
            <p class="text-lg sm:text-xl max-w-4xl"><?php echo e($tSection->sub_heading1); ?></p>
        </div>

        <div class="flex flex-wrap gap-y-4 md:gap-y-8 justify-between md:p-20 p-6 py-9 bg-main2">
            <!-- cards -->
            <?php if(!empty($tSection->other1)): ?>
              <?php $__currentLoopData = $tSection->other1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="p-4 rounded-xl shadow-lg shadow-[#366a60] md:w-[31%] sm:w-[48%] w-full bg-white border border-[#1ABC9C]">
                <div class="flex items-center gap-3 mb-3">
                    <img class="w-12 h-12 rounded-full" src="images/testimonials/client1.png" alt="">
                    <h4 class="text-2xl font-semibold"><?php echo e($item['text1']); ?></h4>
                </div>
                <p><?php echo e($item['text2']); ?></p>
                <div class="flex mt-2 justify-end">
                  <img class="w-5" src="images/icons/Star.png" alt="">
                  <img class="w-5" src="images/icons/Star.png" alt="">
                  <img class="w-5" src="images/icons/Star.png" alt="">
                  <img class="w-5" src="images/icons/Star.png" alt="">
                  <img class="w-5" src="images/icons/Star.png" alt="">
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH D:\laravel\digi\resources\views\pages\inc\tsSection.blade.php ENDPATH**/ ?>