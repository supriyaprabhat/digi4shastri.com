<!-- section3 -->
<?php if(!empty($sections[2]->other1)): ?>
    <?php
        $getCertSection = $sections[2];
    ?>

    <?php if($getCertSection->status == 1): ?>
      <section class="flex md:p-32 py-16 px-4 gap-y-5 justify-between relative flex-wrap bg-circular">

        <?php $__currentLoopData = $sections[2]->other1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white p-6 rounded-lg shadow-2xl transition-all hover:scale-105 space-y-4 md:w-[31%] sm:w-[48%] w-full">
          <img class="w-12" src="<?php echo e(asset('storage/' . $item['image'])); ?>" alt="">
          <h3 class="font-medium text-2xl"><?php echo e($item['text1']); ?></h3>
          <p><?php echo e($item['text2']); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          

      </section>
    <?php endif; ?>
<?php endif; ?>
  <?php /**PATH D:\laravel\digi\resources\views\pages\inc\getCertSection.blade.php ENDPATH**/ ?>