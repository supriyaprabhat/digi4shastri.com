<?php if(!empty($sections[5])): ?>
    <?php
        $sec = $sections[5];
    ?>

    <?php if($sec->status == 1): ?>
        <!-- section6 -->
        <section class="lg:px-28 md:p-20 gap-y-6 py-16 px-4 flex flex-wrap justify-between ">
            <h2 class="text-3xl md:text-4xl  w-full text-red-600 font-semibold"><?php echo e($sec->heading); ?>

            </h2>
            <p class=" md:text-xl  mb-5 w-full font-semibold"><?php echo e($sec->sub_heading1); ?>

            </p>
            <!-- card -->
            <?php $__currentLoopData = $sec->other1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class=" relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col items-center">
                    <img src="<?php echo e(asset('storage/' . $item['image'])); ?>" class="w-28 h-28 rounded-full object-cover" alt="">
                    <div class="pt-20 -mt-16 text-center p-5 rounded-lg -z-10 border-2 w-full border-[#0C5748]">
                        <h3 class="text-red-600 text-xl font-bold mb-1"><?php echo e($item['text1']); ?></h3>
                        <h4 class="text-lg mb-2"><?php echo e($item['text2']); ?></h4>
                        <p class="text-sm"><?php echo e($item['text3']); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    <?php endif; ?>
<?php endif; ?><?php /**PATH D:\laravel\digi\resources\views/pages/inc/corporateSec6.blade.php ENDPATH**/ ?>