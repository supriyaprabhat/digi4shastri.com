<?php if(!empty($sections[5])): ?>
    <?php
        $sec7 = $sections[5];
    ?>

    <?php if($sec7->status == 1): ?>
    <!-- section7 -->
    <section class="flex  mx-auto gap-y-5 md:p-20 p-7 lg:px-28 flex-wrap justify-between items-stretch">
        <h2 class="text-3xl md:text-4xl md:mb-14 mb-8 w-full text-red-600 font-semibold"><?php echo e($sec7->heading); ?></h2>

        <?php if(!empty($sec7->other1)): ?>
            <?php $__currentLoopData = $sec7->other1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="  md:w-[25%] w-[50%] border-x-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
                    <img src="<?php echo e(asset('storage/' . $item['image'])); ?>" class="w-full h-auto max-w-20" alt="">
                    <h4 class="w-full my-3 text-center font-bold text-xl"><?php echo e($item['text1']); ?></h4>
        
                    <p class="text-center mt-2"><?php echo e($item['text2']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        
    </section>
<?php endif; ?>
<?php endif; ?><?php /**PATH D:\laravel\digi\resources\views/pages/inc/aboutSec7.blade.php ENDPATH**/ ?>