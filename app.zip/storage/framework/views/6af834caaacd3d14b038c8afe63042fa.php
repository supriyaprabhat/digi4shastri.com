<?php if(!empty($about[8])): ?>
<?php
        $heroSection = $sections[0];
    ?>

    <?php if($heroSection->status == 1): ?>
    <!-- section9 -->
    <h2 class="text-3xl md:p-20 p-7 lg:px-28 md:text-5xl  w-full text-red-600 font-semibold">Media Spotlight</h2>
    <section class="flex md:p-32 py-16 px-4 gap-y-5 justify-between relative flex-wrap bg-circular">

        <div
            class="bg-white p-6 rounded-lg shadow-2xl transition-all hover:scale-105 space-y-4 md:w-[31%] sm:w-[48%] w-full">
            <img class="w-12" src="images/about/zee.png" alt="">
            <p>
                'IIDE strives to become a prominent facilitator for the entire digital marketing ecosystem' </p>
            <h3 class="text-lg text-right">Sep 15, 2024</h3>
        </div>

        <div
            class="bg-white p-6 rounded-lg shadow-2xl transition-all hover:scale-105 space-y-4 md:w-[31%] sm:w-[48%] w-full">
            <img class="w-12" src="images/about/zee.png" alt="">
            <p>
                'IIDE strives to become a prominent facilitator for the entire digital marketing ecosystem' </p>
            <h3 class="text-lg text-right">Sep 15, 2024</h3>
        </div>

        <div
            class="bg-white p-6 rounded-lg shadow-2xl transition-all hover:scale-105 space-y-4 md:w-[31%] sm:w-[48%] w-full">
            <img class="w-12" src="images/about/zee.png" alt="">
            <p>
                'IIDE strives to become a prominent facilitator for the entire digital marketing ecosystem' </p>
            <h3 class="text-lg text-right">Sep 15, 2024</h3>
        </div>


    </section>
<?php endif; ?>
<?php endif; ?><?php /**PATH D:\laravel\digi\resources\views\pages\inc\aboutSec9.blade.php ENDPATH**/ ?>