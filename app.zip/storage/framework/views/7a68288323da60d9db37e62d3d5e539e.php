<!-- section2 -->
<?php if(!empty($course->cards)): ?>
    <section class="flex  mx-auto gap-y-5 md:p-20 p-7 lg:px-28 flex-wrap justify-between items-center">
        <?php $__currentLoopData = $course->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex justify-around p-4 gap-2 sm:w-[47%] md:w-[31%] items-center w-full border border-[#138972] rounded-lg hover:shadow-xl transition-all duration-500">
                <div class="md:text-5xl text-4xl font-bold text-yellow-400"><i class="<?php echo e($item['icon_code']); ?>"></i></div>
                <div>
                    <h2 class="font-bold md:text-2xl  text-xl"><?php echo e($item['heading']); ?></h2>
                    <p><?php echo e($item['texts']); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php endif; ?><?php /**PATH D:\laravel\digi\resources\views\pages\inc\courseSec2.blade.php ENDPATH**/ ?>