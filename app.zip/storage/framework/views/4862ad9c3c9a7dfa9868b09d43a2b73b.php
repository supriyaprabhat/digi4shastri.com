<!-- section 10 -->
<?php if(!empty($course->career_supports)): ?>
    <section class="flex  mx-auto gap-y-5 md:p-20 p-7 lg:px-28 flex-wrap justify-between items-stretch">
        <h2 class="text-3xl md:text-5xl md:mb-14 mb-8 w-full text-red-600 font-semibold">Bonus Module</h2>

        <?php $__currentLoopData = $course->career_supports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="  md:w-[22%] w-[47%] border-2 border-t-white border-[#1ABC9C] hover:shadow-md shadow-lg p-4 flex justify-around items-center flex-col">
                <img src="<?php echo e(asset('storage/' . $item['icon'])); ?>" class="w-full h-auto max-w-20" alt="">
                <h4 class="w-full mt-3 text-center font-bold text-xl"><?php echo e($item['heading']); ?></h4>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>
<?php endif; ?>
<?php /**PATH D:\laravel\digi\resources\views/pages/inc/courseSec10.blade.php ENDPATH**/ ?>