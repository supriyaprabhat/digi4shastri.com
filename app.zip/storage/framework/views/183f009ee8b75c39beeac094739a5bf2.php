 <!-- section3 -->
 <section class="md:p-20 p-7 lg:px-28">


    <div class="flex flex-wrap  justify-between items-center gap-y-7">
        <div class="md:w-[52%] w-full py-11">
            <h2 class="text-3xl md:text-5xl mb-7 md:mb-14 text-red-600 font-semibold">Course Curriculum</h2>
            <!-- tabs -->
            <div class="flex flex-wrap mb-9  gap-5">
                <div class="tabs max-w-max gap-3" id="tab1" onclick="toggleTab(0)">
                    <div><i class="fa-solid fa-computer"></i></div>
                    <p>Digital Marketing Section</p>
                </div>
                <div class="tabs max-w-max gap-3 active" id="tab2" onclick="toggleTab(1)">
                    <div><i class="fa-solid fa-computer"></i></div>
                    <p>Digital Marketing Section</p>
                </div>
            </div>
            <!-- Modules -->
            <div class="space-y-4 hid sm:h-[470px] sm:overflow-auto " id="opentab1">
                <?php if(!empty($course->curriculum_tab_1)): ?>
                    <?php $__currentLoopData = $course->curriculum_tab_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="module">
                            <div class="flex items-center gap-2 cursor-pointer" onclick="toggleModule(this)">
                                <div class="font-bold text-4xl text-green-700 -mt-2">+</div>
                                <h2 class="sm:text-2xl text-xl font-medium"><?php echo e($item['module']); ?></h2>
                            </div>
                            <ul class="list-disc list-inside ml-9 ">
                                <?php $__currentLoopData = $item['activities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($activity['activity']); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

            <div class="space-y-4 sm:h-[470px] sm:overflow-auto " id="opentab2">
                <?php if(!empty($course->curriculum_tab_2)): ?>
                    <?php $__currentLoopData = $course->curriculum_tab_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="module">
                            <div class="flex items-center gap-2 cursor-pointer" onclick="toggleModule(this)">
                                <div class="font-bold text-4xl text-green-700 -mt-2">+</div>
                                <h2 class="sm:text-2xl text-xl font-medium"><?php echo e($item1['module']); ?></h2>
                            </div>
                            <ul class="list-disc list-inside ml-9 ">
                                <?php $__currentLoopData = $item1['activities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($activity1['activity']); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="md:w-[32%] w-full">
            <img src="<?php echo e(asset('images/course/girl.png')); ?>" alt="">
        </div>

    </div>
</section><?php /**PATH D:\laravel\digi\resources\views/pages/inc/courseSec3.blade.php ENDPATH**/ ?>