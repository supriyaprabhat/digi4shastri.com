

<?php $__env->startSection('title'); ?> 
    Corporate - Digi4shastri
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
   
<!-- section1 -->
<section class="lg:p-28 md:p-20 p-7 pb-14 relative flex flex-wrap gap-y-5  justify-between items-center">
    <img src="images/center/bg.png" class="rotate-180 w-full h-full absolute top-0 left-0" alt="">
    <div class="sm:w-[48%] w-full">
        <h1 class="lg:text-6xl text-4xl text-red-600 font-medium  mb-11">Future-proof your company with IIDEPRO
            corporate training program</h1>
        <p class="text-lg md:text-xl font-medium mb-8">Latest technologies and innovative techniques to transform
            employee's learning and accelerate your business growth</p>
        <p class="text-xl md:text-2xl font-medium mb-11">Customized Content | Online & Offline | Professional
            Certification</p>
        <a href="" class="btn-p !mx-auto !px-8 cursor-pointer shadow-lg  max-sm:mx-auto">Enquire Now</a>
    </div>
    <div class="relative sm:w-[48%] w-full">
        <img src="images/corporate/banner-bg.png" class="w-full h-full" alt="">

        <div class="bg-rad-grey absolute p-2 top-24  right-5 text-center max-w-52 w-[38vw]">
            <h4 class="text-xl text-red-600 font-medium md:text-2xl">5+</h4>
            <p class="max-sm:text-xs">Years of Corporate Training</p>
        </div>

        <div class="bg-rad-grey absolute p-2 bottom-20 right-2 text-center max-w-60 w-[39vw]">
            <h4 class="text-xl text-red-600 font-medium md:text-2xl">100+</h4>
            <p class="max-sm:text-xs">Corporate Partnerships Globally</p>
        </div>

        <div class="bg-rad-grey absolute p-2 bottom-28 left-0 text-center max-w-48 w-[38vw]">
            <h4 class="text-xl text-red-600 font-medium md:text-2xl ">5000+</h4>
            <p class="max-sm:text-xs">Professionals Trained</p>
        </div>
    </div>
</section>

<!-- section2 -->
<section class="flex  mx-auto gap-y-5 md:p-20 p-7 lg:px-28 flex-wrap justify-between items-stretch">
    <h2 class="text-3xl md:text-4xl md:mb-14 mb-8 w-full text-red-600 font-semibold">Our Corporate Clients</h2>

    <!-- cards -->
    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>

    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>

    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>

    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>

    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>

    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>
    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>

    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>
    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>

    <div
        class="  md:w-[24%] sm:w-[31%] w-[48%] border-2  border-[#1ABC9C] px-8 flex justify-around items-center flex-col">
        <img src="images/icons/award.png" class="w-full h-auto max-w-20" alt="">
    </div>
    </div>
</section>

<!-- section3 -->
<section class="flex  mx-auto gap-y-5 md:p-20 p-7 lg:px-28 flex-wrap justify-between items-stretch">
    <h2 class="text-3xl md:text-4xl md:mb-10 mb-5 w-full text-red-600 font-semibold">Client Stories</h2>
    <!-- slider -->
    <div class="swiper2 mx-auto w-full h-auto mt-7 pb-14 overflow-hidden relative">
        <!-- Additional required wrapper -->
        <div class="swiper-wrapper">

            <div class="swiper-slide text-center  card-bg">
                <p class="bg-[#1ABC9C] text-center p-4 text-lg font-bold">Client LOgo</p>
                <div class="p-6 pb-9">
                    <p class="text-center mb-11">Cipla was looking for specialists to diagnose their digital
                        marketing needs.
                        What did we prescribe for Cipla's digital bug?</p>
                    <a href="" class="btn-p px-8 cursor-pointer shadow-lg  mx-auto">Read More</a>
                </div>
            </div>

            <div class="swiper-slide text-center  card-bg">
                <p class="bg-[#1ABC9C] text-center p-4 text-lg font-bold">Client LOgo</p>
                <div class="p-6 pb-9">
                    <p class="text-center mb-11">Cipla was looking for specialists to diagnose their digital
                        marketing needs.
                        What did we prescribe for Cipla's digital bug?</p>
                    <a href="" class="btn-p px-8 cursor-pointer shadow-lg  mx-auto">Read More</a>
                </div>
            </div>

            <div class="swiper-slide text-center  card-bg">
                <p class="bg-[#1ABC9C] text-center p-4 text-lg font-bold">Client LOgo</p>
                <div class="p-6 pb-9">
                    <p class="text-center mb-11">Cipla was looking for specialists to diagnose their digital
                        marketing needs.
                        What did we prescribe for Cipla's digital bug?</p>
                    <a href="" class="btn-p px-8 cursor-pointer shadow-lg  mx-auto">Read More</a>
                </div>
            </div>

            <div class="swiper-slide text-center  card-bg">
                <p class="bg-[#1ABC9C] text-center p-4 text-lg font-bold">Client LOgo</p>
                <div class="p-6 pb-9">
                    <p class="text-center mb-11">Cipla was looking for specialists to diagnose their digital
                        marketing needs.
                        What did we prescribe for Cipla's digital bug?</p>
                    <a href="" class="btn-p px-8 cursor-pointer shadow-lg  mx-auto">Read More</a>
                </div>
            </div>
        </div>

        <div class="mt-8 text-center">
            <div class="swiper-pagination2"></div>
        </div>

    </div>
</section>

<!-- section4 -->
<section class="lg:px-28 md:p-20 py-16 px-4">
    <div
        class="flex flex-wrap rounded-2xl border-4 gap-3 border-white shadow-md items-center justify-between md:px-20 py-10 px-8 bg-main relative">
        <div class="md:w-[60%] ">
            <h2 class="text-3xl font-semibold md:text-4xl text-white">Digi4shastri Signature can boost your
                on-boarding.</h2>
        </div>
        <div><a href="" class="btn-p min-w-max cursor-pointer ">Get Boucher</a></div>

    </div>
</section>

<!-- section5 -->
<section class="lg:px-28 md:p-20 py-16 px-4 flex flex-wrap justify-between gap-y-14">
    <h2 class="text-3xl md:text-4xl w-full text-red-600 font-semibold">Our Corporate Training Offerings
    </h2>
    <!-- card -->
    <div class="bg-img h-[400px] relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col justify-center"
        style="background-image:linear-gradient(0deg, rgba(0, 0, 0, 0.492), rgba(0, 0, 0, 0.442)), url(images/home/img3.png);">
        <h5 class="text-white font-bold text-3xl">Learning Management Ecosystem</h5>
        <div
            class="w-[80%]  absolute opacity-0 group-hover:opacity-100 duration-300 top-[10%] left-[10%] pt-11 bg-main2 p-5 text-left">
            <a href="" class="btn-p !mx-auto !px-8 cursor-pointer ">Select</a>
            <h3 class="text-2xl text-yellow-400 mt-6">A-la-carte Learning Solution</h3>
            <ul class="space-y-1 mt-5 text-lg mb-8">
                <h3>• Ideal for skilling teams</h3>
                <h3>• Curriculum delivered LIVE by content experts</h>
                    <h3>• Online or Offline Interaction</h3>
            </ul>
            <a href="">
                <div
                    class=" text-center cursor-pointer bg-[#0D5B4B] hover:bg-black text-white py-3 px-11 text-lg duration-300 ">
                    Learn more
                </div>
            </a>
        </div>
    </div>

    <!-- card -->
    <div class="bg-img h-[400px] relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col justify-center"
        style="background-image:linear-gradient(0deg, rgba(0, 0, 0, 0.492), rgba(0, 0, 0, 0.442)), url(images/home/img3.png);">
        <h5 class="text-white font-bold text-3xl">Learning Management Ecosystem</h5>
        <div
            class="w-[80%]  absolute opacity-0 group-hover:opacity-100 duration-300 top-[10%] left-[10%] pt-11 bg-main2 p-5 text-left">
            <a href="" class="btn-p !mx-auto !px-8 cursor-pointer ">Select</a>
            <h3 class="text-2xl text-yellow-400 mt-6">A-la-carte Learning Solution</h3>
            <ul class="space-y-1 mt-5 text-lg mb-8">
                <h3>• Ideal for skilling teams</h3>
                <h3>• Curriculum delivered LIVE by content experts</h>
                    <h3>• Online or Offline Interaction</h3>
            </ul>
            <a href="">
                <div
                    class=" text-center cursor-pointer bg-[#0D5B4B] hover:bg-black text-white py-3 px-11 text-lg duration-300 ">
                    Learn more
                </div>
            </a>
        </div>
    </div>

    <!-- card -->
    <div class="bg-img h-[400px] relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col justify-center"
        style="background-image:linear-gradient(0deg, rgba(0, 0, 0, 0.492), rgba(0, 0, 0, 0.442)), url(images/home/img3.png);">
        <h5 class="text-white font-bold text-3xl">Learning Management Ecosystem</h5>
        <div
            class="w-[80%]  absolute opacity-0 group-hover:opacity-100 duration-300 top-[10%] left-[10%] pt-11 bg-main2 p-5 text-left">
            <a href="" class="btn-p !mx-auto !px-8 cursor-pointer ">Select</a>
            <h3 class="text-2xl text-yellow-400 mt-6">A-la-carte Learning Solution</h3>
            <ul class="space-y-1 mt-5 text-lg mb-8">
                <h3>• Ideal for skilling teams</h3>
                <h3>• Curriculum delivered LIVE by content experts</h>
                    <h3>• Online or Offline Interaction</h3>
            </ul>
            <a href="">
                <div
                    class=" text-center cursor-pointer bg-[#0D5B4B] hover:bg-black text-white py-3 px-11 text-lg duration-300 ">
                    Learn more
                </div>
            </a>
        </div>
    </div>

</section>

<!-- section6 -->

<section class="lg:px-28 md:p-20 gap-y-6 py-16 px-4 flex flex-wrap justify-between ">
    <h2 class="text-3xl md:text-4xl  w-full text-red-600 font-semibold">Our Panel Of Corporate Trainers
    </h2>
    <p class=" md:text-xl  mb-5 w-full font-semibold">Our team of content experts - empanelled with IIDE or
        hand-picked from the industry based on your learning outcome.
    </p>
    <!-- card -->
    <div class=" relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col items-center">
        <img src="images/home/img1.png" class="w-28 h-28 rounded-full object-cover" alt="">
        <div class="pt-20 -mt-16 text-center p-5 rounded-lg -z-10 border-2 w-full border-[#0C5748]">
            <h3 class="text-red-600 text-xl font-bold mb-1">Reshma Shaikh</h3>
            <h4 class="text-lg mb-2">Associate Team Lead, Digi4shastri</h4>
            <p class="text-sm">Reshma is obsessed with identifying business problems, strategically fixing them &
                fueling growth.</p>
            <p class="text-sm"> She is level Pro in SEO, Google Ads & WordPress and has trained 5000 learners to
                harness the power of digital in driving business success.</p>
        </div>
    </div>

    <!-- card -->
    <div class=" relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col items-center">
        <img src="images/home/img1.png" class="w-28 h-28 rounded-full object-cover" alt="">
        <div class="pt-20 -mt-16 text-center p-5 rounded-lg -z-10 border-2 w-full border-[#0C5748]">
            <h3 class="text-red-600 text-xl font-bold mb-1">Reshma Shaikh</h3>
            <h4 class="text-lg mb-2">Associate Team Lead, Digi4shastri</h4>
            <p class="text-sm">Reshma is obsessed with identifying business problems, strategically fixing them &
                fueling growth.</p>
            <p class="text-sm"> She is level Pro in SEO, Google Ads & WordPress and has trained 5000 learners to
                harness the power of digital in driving business success.</p>
        </div>
    </div>

    <!-- card -->
    <div class=" relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col items-center">
        <img src="images/home/img1.png" class="w-28 h-28 rounded-full object-cover" alt="">
        <div class="pt-20 -mt-16 text-center p-5 rounded-lg -z-10 border-2 w-full border-[#0C5748]">
            <h3 class="text-red-600 text-xl font-bold mb-1">Reshma Shaikh</h3>
            <h4 class="text-lg mb-2">Associate Team Lead, Digi4shastri</h4>
            <p class="text-sm">Reshma is obsessed with identifying business problems, strategically fixing them &
                fueling growth.</p>
            <p class="text-sm"> She is level Pro in SEO, Google Ads & WordPress and has trained 5000 learners to
                harness the power of digital in driving business success.</p>
        </div>
    </div>
    <!-- card -->
    <div class=" relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col items-center">
        <img src="images/home/img1.png" class="w-28 h-28 rounded-full object-cover" alt="">
        <div class="pt-20 -mt-16 text-center p-5 rounded-lg -z-10 border-2 w-full border-[#0C5748]">
            <h3 class="text-red-600 text-xl font-bold mb-1">Reshma Shaikh</h3>
            <h4 class="text-lg mb-2">Associate Team Lead, Digi4shastri</h4>
            <p class="text-sm">Reshma is obsessed with identifying business problems, strategically fixing them &
                fueling growth.</p>
            <p class="text-sm"> She is level Pro in SEO, Google Ads & WordPress and has trained 5000 learners to
                harness the power of digital in driving business success.</p>
        </div>
    </div>
    <!-- card -->
    <div class=" relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col items-center">
        <img src="images/home/img1.png" class="w-28 h-28 rounded-full object-cover" alt="">
        <div class="pt-20 -mt-16 text-center p-5 rounded-lg -z-10 border-2 w-full border-[#0C5748]">
            <h3 class="text-red-600 text-xl font-bold mb-1">Reshma Shaikh</h3>
            <h4 class="text-lg mb-2">Associate Team Lead, Digi4shastri</h4>
            <p class="text-sm">Reshma is obsessed with identifying business problems, strategically fixing them &
                fueling growth.</p>
            <p class="text-sm"> She is level Pro in SEO, Google Ads & WordPress and has trained 5000 learners to
                harness the power of digital in driving business success.</p>
        </div>
    </div>
    <!-- card -->
    <div class=" relative group md:w-[31%] sm:w-[48%] w-full text-center flex flex-col items-center">
        <img src="images/home/img1.png" class="w-28 h-28 rounded-full object-cover" alt="">
        <div class="pt-20 -mt-16 text-center p-5 rounded-lg -z-10 border-2 w-full border-[#0C5748]">
            <h3 class="text-red-600 text-xl font-bold mb-1">Reshma Shaikh</h3>
            <h4 class="text-lg mb-2">Associate Team Lead, Digi4shastri</h4>
            <p class="text-sm">Reshma is obsessed with identifying business problems, strategically fixing them &
                fueling growth.</p>
            <p class="text-sm"> She is level Pro in SEO, Google Ads & WordPress and has trained 5000 learners to
                harness the power of digital in driving business success.</p>
        </div>
    </div>

</section>

<!-- section7 -->
<section class="lg:px-28 md:p-20 py-16 px-4">
    <div
        class="flex flex-wrap rounded-2xl border-4 gap-3 border-white shadow-md items-center justify-between md:px-20 py-10 px-8 bg-main relative">
        <div class="md:w-[60%] ">
            <h2 class="text-3xl font-semibold md:text-4xl text-white">IIDEPRO Select can upskill employees in just 1
                day.</h2>
        </div>
        <div><a href="" class="btn-p min-w-max cursor-pointer ">Get Boucher</a></div>

    </div>
</section>

<!-- section8 -->
<section class="md:p-20 p-7 lg:px-28">
    <h2 class="text-3xl md:text-5xl md:mb-14 mb-8 w-full text-red-600 font-semibold">Words Of Praise From Leading
        Corporates
    </h2>


    <!-- slider -->
    <div class="swiper2  mx-auto w-full h-auto mt-11 overflow-hidden relative">
        <!-- Additional required wrapper -->
        <div class="swiper-wrapper text-white">
            <div
                class="swiper-slide relative px-7 py-10 my-7 rounded-xl shadow-lg shadow-[#366a60]  w-full bg-main2">
                <img src="images/course/quote.png" class="w-[20%]  absolute right-4 -top-7" alt="">

                <div class="flex  mb-6"><img class="w-5" src="images/icons/Star.png" alt=""><img class="w-5"
                        src="images/icons/Star.png" alt=""><img class="w-5" src="images/icons/Star.png" alt=""><img
                        class="w-5" src="images/icons/Star.png" alt=""><img class="w-5" src="images/icons/Star.png"
                        alt=""></div>

                <p class="mb-6">Best Digital Marketing Career Academy among all! I suggest all my friends about
                    DigishastriShastri . They provide depth course module both technically and strategically. Happy
                    to be a part of Digishastri.</p>
                <hr>
                <div class="flex items-center gap-3 mt-3">
                    <img class="w-12 h-12 rounded-full" src="images/testimonials/client1.png" alt="">
                    <h4 class="text-2xl font-semibold">Kimz Hnamte</h4>
                </div>
            </div>

            <div
                class="swiper-slide relative px-7 py-10 my-7 rounded-xl shadow-lg shadow-[#366a60]  w-full bg-main2">
                <img src="images/course/quote.png" class="w-[20%]  absolute right-4 -top-7" alt="">

                <div class="flex  mb-6"><img class="w-5" src="images/icons/Star.png" alt=""><img class="w-5"
                        src="images/icons/Star.png" alt=""><img class="w-5" src="images/icons/Star.png" alt=""><img
                        class="w-5" src="images/icons/Star.png" alt=""><img class="w-5" src="images/icons/Star.png"
                        alt=""></div>

                <p class="mb-6">Best Digital Marketing Career Academy among all! I suggest all my friends about
                    DigishastriShastri . They provide depth course module both technically and strategically. Happy
                    to be a part of Digishastri.</p>
                <hr>
                <div class="flex items-center gap-3 mt-3">
                    <img class="w-12 h-12 rounded-full" src="images/testimonials/client1.png" alt="">
                    <h4 class="text-2xl font-semibold">Kimz Hnamte</h4>
                </div>
            </div>

            <div
                class="swiper-slide relative px-7 py-10 my-7 rounded-xl shadow-lg shadow-[#366a60]  w-full bg-main2">
                <img src="images/course/quote.png" class="w-[20%]  absolute right-4 -top-7" alt="">

                <div class="flex  mb-6"><img class="w-5" src="images/icons/Star.png" alt=""><img class="w-5"
                        src="images/icons/Star.png" alt=""><img class="w-5" src="images/icons/Star.png" alt=""><img
                        class="w-5" src="images/icons/Star.png" alt=""><img class="w-5" src="images/icons/Star.png"
                        alt=""></div>

                <p class="mb-6">Best Digital Marketing Career Academy among all! I suggest all my friends about
                    DigishastriShastri . They provide depth course module both technically and strategically. Happy
                    to be a part of Digishastri.</p>
                <hr>
                <div class="flex items-center gap-3 mt-3">
                    <img class="w-12 h-12 rounded-full" src="images/testimonials/client1.png" alt="">
                    <h4 class="text-2xl font-semibold">Kimz Hnamte</h4>
                </div>
            </div>

            <div
                class="swiper-slide relative px-7 py-10 my-7 rounded-xl shadow-lg shadow-[#366a60]  w-full bg-main2">
                <img src="images/course/quote.png" class="w-[20%]  absolute right-4 -top-7" alt="">

                <div class="flex  mb-6"><img class="w-5" src="images/icons/Star.png" alt=""><img class="w-5"
                        src="images/icons/Star.png" alt=""><img class="w-5" src="images/icons/Star.png" alt=""><img
                        class="w-5" src="images/icons/Star.png" alt=""><img class="w-5" src="images/icons/Star.png"
                        alt=""></div>

                <p class="mb-6">Best Digital Marketing Career Academy among all! I suggest all my friends about
                    DigishastriShastri . They provide depth course module both technically and strategically. Happy
                    to be a part of Digishastri.</p>
                <hr>
                <div class="flex items-center gap-3 mt-3">
                    <img class="w-12 h-12 rounded-full" src="images/testimonials/client1.png" alt="">
                    <h4 class="text-2xl font-semibold">Kimz Hnamte</h4>
                </div>
            </div>
        </div>

        <div class="mt-14 text-center">
            <div class="swiper-pagination2"></div>
        </div>
    </div>
</section>

<!-- section9 -->
<section class="md:p-20 p-7 lg:px-28">
    <h2 class="text-3xl md:text-5xl md:mb-14 mb-8 w-full text-red-600 font-semibold">Glimpse of past trainings
    </h2>


    <!-- slider -->
    <div class="swiper  mx-auto w-full h-auto mt-11 overflow-hidden relative">
        <!-- Additional required wrapper -->
        <div class="swiper-wrapper text-white">
            <div class="swiper-slide yt">
                <img src="images/corporate/yt.png" alt="">
            </div>

            <div class="swiper-slide yt">
                <img src="images/corporate/yt.png" alt="">
            </div>

            <div class="swiper-slide yt">
                <img src="images/corporate/yt.png" alt="">
            </div>

            <div class="swiper-slide ">
                <img src="images/corporate/yt.png" alt="">
            </div>
            <div class="swiper-slide ">
                <img src="images/corporate/yt.png" alt="">
            </div>

        </div>

        <div class="mt-14 text-center">
            <div class="swiper-pagination"></div>
        </div>
    </div>
</section>

<!-- section10 -->
<section class="max-w-7xl lg:px-28 md:p-20 p-7 mx-auto flex flex-wrap items-stretch">
    <div class="md:w-[35%] bg-[#19B697] sm:w-[25%] w-full flex flex-col justify-center items-center py-20 px-6">
        <h2 class="md:text-9xl text-8xl mb-4 text-yellow-400 font-medium">45%</h2>
        <p class="text-xl font-bold text-center">of organisations don't have a defined digital strategy. We are here
            to help.</p>
    </div>
    <div class="md:w-[65%] border-2 border-[#19B697] sm:w-[75%] w-full">
        <form class="p-7 md:p-11 w-full flex flex-wrap justify-between" action="">
            <h3 class="text-2xl w-full text-red-600 sm:text-3xl font-bold mb-8">Get Free Career Counseling.</h3>
            <div class="mb-4 sm:w-[48%] w-full space-y-2 flex flex-col">
                <label for="name" class="text-lg font-medium">FIRST NAME</label>
                <input type="text" name="name" id="name" class="p-3 border-2">
            </div>
            <div class="mb-4 sm:w-[48%] w-full space-y-2 flex flex-col">
                <label for="name" class="text-lg font-medium">LAST NAME</label>
                <input type="text" name="name" id="name" class="p-3 border-2">
            </div>

            <div class="mb-4 space-y-2 flex flex-col sm:w-[48%] w-full">
                <label for="email" class="text-lg font-medium">EMAIL</label>
                <input type="text" name="email" id="email" class="p-3 border-2">
            </div>
            <div class="mb-4 space-y-2 flex flex-col sm:w-[48%] w-full">
                <label for="email" class="text-lg font-medium">Mobile</label>
                <input type="text" name="phone" id="phone" class="p-3 border-2">
            </div>
            <div class="mb-4 space-y-2 flex flex-col sm:w-[48%] w-full">
                <label for="email" class="text-lg font-medium">City</label>
                <input type="text" name="city" id="city" class="p-3 border-2">
            </div>
            <div class="mb-4 space-y-2 flex flex-col sm:w-[48%] w-full">
                <label for="email" class="text-lg font-medium">Select a time</label>
                <input type="text" name="time" id="time" class="p-3 border-2">
            </div>

            <div class="mb-8 w-full space-y-2 flex flex-col">
                <label for="name" class="text-lg font-medium">MESSAGE</label>
                <textarea name="message" id="message" class="p-3 border-2"></textarea>
            </div>

            <button class="btn-p w-full !border-2 !border-zinc-900" type="submit">Send Now</button>
        </form>
    </div>
</section>

<!-- section11 faqs -->
<section class="md:p-20 p-7 lg:px-28">
    <!-- FAQ  -->
    <div class="mb-11">
        <h4 class="text-3xl sm:text-5xl text-red-600 font-bold">Frequently Asked Questions</h4>
    </div>
    <div class="faq ">
        <div class="active faq-item p-4 mb-3 shadow-xl">
            <div class="question">
                <h3 class="text-xl font-bold">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                </h3>
                <i class="fa-solid fa-circle-chevron-down"></i>
            </div>
            <div class="answer">
                <hr class="my-3" />
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat deleniti iste facere molestias in
                soluta sapiente maxime accusamus aliquam rerum facilis itaque consequatur reprehenderit odit quis
                laborum eveniet, ex earum!
                <br />
            </div>
        </div>
        <div class="faq-item p-4 mb-3 shadow-xl">
            <div class="question">
                <h3 class="text-xl font-bold">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                </h3>
                <i class="fa-solid fa-circle-chevron-down"></i>
            </div>
            <div class="answer">
                <hr class="my-3" />
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat deleniti iste facere molestias in
                soluta sapiente maxime accusamus aliquam rerum facilis itaque consequatur reprehenderit odit quis
                laborum eveniet, ex earum!
                <br />
            </div>
        </div>
        <div class="faq-item p-4 mb-3 shadow-xl">
            <div class="question">
                <h3 class="text-xl font-bold">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                </h3>
                <i class="fa-solid fa-circle-chevron-down"></i>
            </div>
            <div class="answer">
                <hr class="my-3" />
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat deleniti iste facere molestias in
                soluta sapiente maxime accusamus aliquam rerum facilis itaque consequatur reprehenderit odit quis
                laborum eveniet, ex earum!
                <br />
            </div>
        </div>
        <div class="faq-item p-4 mb-3 shadow-xl">
            <div class="question">
                <h3 class="text-xl font-bold">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                </h3>
                <i class="fa-solid fa-circle-chevron-down"></i>
            </div>
            <div class="answer">
                <hr class="my-3" />
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat deleniti iste facere molestias in
                soluta sapiente maxime accusamus aliquam rerum facilis itaque consequatur reprehenderit odit quis
                laborum eveniet, ex earum!
                <br />
            </div>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\digi\resources\views\pages\corporate.blade.php ENDPATH**/ ?>