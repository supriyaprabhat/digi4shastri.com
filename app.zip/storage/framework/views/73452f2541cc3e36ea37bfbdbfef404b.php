<!-- section8 -->
<section class=" md:p-20 p-7 lg:px-28 mt-11">
    <h2 class="text-3xl md:text-5xl md:mb-14 mb-8 w-full text-red-600 font-semibold">
        Projects, Case-Studies & Assignments</h2>
    <div class="flex overflow-auto mb-9 max-w-lg justify-between  gap-5">
        <div class="tabs min-w-max gap-3" id="tab3" onclick="toggleTab2(0)">
            <div><i class="fa-solid fa-computer"></i></div>
            <p>Assignments</p>
        </div>
        <div class="tabs min-w-max gap-3 " id="tab4" onclick="toggleTab2(1)">
            <div><i class="fa-solid fa-computer"></i></div>
            <p>Projects</p>
        </div>
        <div class="tabs min-w-max gap-3 active" id="tab5" onclick="toggleTab2(2)">
            <div><i class="fa-solid fa-computer"></i></div>
            <p>Case- Studies</p>
        </div>
    </div>
    <div class="space-y-4 hid" id="opentab3">
        <?php $__currentLoopData = $course->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="md:text-lg font-medium"><strong class="text-red-600 font-bold"><?php echo e($item['heading']); ?></strong> <?php echo e($item['texts']); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="space-y-4 hid" id="opentab4">
        <?php $__currentLoopData = $course->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="md:text-lg font-medium"><strong class="text-red-600 font-bold"><?php echo e($item['heading']); ?></strong> <?php echo e($item['texts']); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="space-y-4" id="opentab5">
        <?php $__currentLoopData = $course->case_studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="md:text-lg font-medium"><strong class="text-red-600 font-bold"><?php echo e($item['heading']); ?></strong> <?php echo e($item['texts']); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section><?php /**PATH D:\laravel\digi\resources\views/pages/inc/courseSec8.blade.php ENDPATH**/ ?>