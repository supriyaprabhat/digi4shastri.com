<?php if(!empty($sections[2])): ?>
    <?php
        $sec3 = $sections[2];
    ?>

    <?php if($sec3->status == 1): ?>
    <!-- section3 -->
    <section class="flex bg-grid mx-auto gap-y-5 md:p-20 p-7 lg:px-28 flex-wrap justify-between items-stretch">
        <h2 class="text-4xl md:text-5xl md:mb-14 mb-8 w-full text-red-600 font-semibold"><?php echo e($sec3->heading); ?>

        </h2>

        <!-- cards -->
        <?php if(!empty($sec3->other1)): ?>
            <?php $__currentLoopData = $sec3->other1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="  md:w-[22%] w-[47%] hover:shadow-md shadow-lg p-4 flex justify-around items-center flex-col bg-white">
                    <div class="w-16 h-16 p-1 text-center rounded-full border-4 border-red-600"><i
                            class="fa-solid fa-globe text-5xl text-[#014235]"></i></div>
                    <h4 class="w-full mt-3 text-center sm:text-4xl text-3xl"><?php echo e($item['text1']); ?></h4>
                    <p class="text-xl mt-1 text-center"><?php echo e($item['text2']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        
        </div>
    </section>
<?php endif; ?>
<?php endif; ?><?php /**PATH D:\laravel\digi\resources\views\pages\inc\aboutSec3.blade.php ENDPATH**/ ?>