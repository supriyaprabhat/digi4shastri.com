<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.blog-resource.pages.create-blog' => 'App\\Filament\\Resources\\BlogResource\\Pages\\CreateBlog',
    'app.filament.resources.blog-resource.pages.edit-blog' => 'App\\Filament\\Resources\\BlogResource\\Pages\\EditBlog',
    'app.filament.resources.blog-resource.pages.list-blogs' => 'App\\Filament\\Resources\\BlogResource\\Pages\\ListBlogs',
    'app.filament.resources.career-counselling-resource.pages.create-career-counselling' => 'App\\Filament\\Resources\\CareerCounsellingResource\\Pages\\CreateCareerCounselling',
    'app.filament.resources.career-counselling-resource.pages.edit-career-counselling' => 'App\\Filament\\Resources\\CareerCounsellingResource\\Pages\\EditCareerCounselling',
    'app.filament.resources.career-counselling-resource.pages.list-career-counsellings' => 'App\\Filament\\Resources\\CareerCounsellingResource\\Pages\\ListCareerCounsellings',
    'app.filament.resources.center-resource.pages.create-center' => 'App\\Filament\\Resources\\CenterResource\\Pages\\CreateCenter',
    'app.filament.resources.center-resource.pages.edit-center' => 'App\\Filament\\Resources\\CenterResource\\Pages\\EditCenter',
    'app.filament.resources.center-resource.pages.list-centers' => 'App\\Filament\\Resources\\CenterResource\\Pages\\ListCenters',
    'app.filament.resources.consultation-resource.pages.create-consultation' => 'App\\Filament\\Resources\\ConsultationResource\\Pages\\CreateConsultation',
    'app.filament.resources.consultation-resource.pages.edit-consultation' => 'App\\Filament\\Resources\\ConsultationResource\\Pages\\EditConsultation',
    'app.filament.resources.consultation-resource.pages.list-consultations' => 'App\\Filament\\Resources\\ConsultationResource\\Pages\\ListConsultations',
    'app.filament.resources.contact-resource.pages.create-contact' => 'App\\Filament\\Resources\\ContactResource\\Pages\\CreateContact',
    'app.filament.resources.contact-resource.pages.edit-contact' => 'App\\Filament\\Resources\\ContactResource\\Pages\\EditContact',
    'app.filament.resources.contact-resource.pages.list-contacts' => 'App\\Filament\\Resources\\ContactResource\\Pages\\ListContacts',
    'app.filament.resources.course-resource.pages.create-course' => 'App\\Filament\\Resources\\CourseResource\\Pages\\CreateCourse',
    'app.filament.resources.course-resource.pages.edit-course' => 'App\\Filament\\Resources\\CourseResource\\Pages\\EditCourse',
    'app.filament.resources.course-resource.pages.list-courses' => 'App\\Filament\\Resources\\CourseResource\\Pages\\ListCourses',
    'app.filament.resources.free-counseling-resource.pages.create-free-counseling' => 'App\\Filament\\Resources\\FreeCounselingResource\\Pages\\CreateFreeCounseling',
    'app.filament.resources.free-counseling-resource.pages.edit-free-counseling' => 'App\\Filament\\Resources\\FreeCounselingResource\\Pages\\EditFreeCounseling',
    'app.filament.resources.free-counseling-resource.pages.list-free-counselings' => 'App\\Filament\\Resources\\FreeCounselingResource\\Pages\\ListFreeCounselings',
    'app.filament.resources.general-resource.pages.create-general' => 'App\\Filament\\Resources\\GeneralResource\\Pages\\CreateGeneral',
    'app.filament.resources.general-resource.pages.edit-general' => 'App\\Filament\\Resources\\GeneralResource\\Pages\\EditGeneral',
    'app.filament.resources.general-resource.pages.list-generals' => 'App\\Filament\\Resources\\GeneralResource\\Pages\\ListGenerals',
    'app.filament.resources.page-resource.pages.create-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\CreatePage',
    'app.filament.resources.page-resource.pages.edit-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\EditPage',
    'app.filament.resources.page-resource.pages.list-pages' => 'App\\Filament\\Resources\\PageResource\\Pages\\ListPages',
    'app.filament.resources.section-resource.pages.create-section' => 'App\\Filament\\Resources\\SectionResource\\Pages\\CreateSection',
    'app.filament.resources.section-resource.pages.edit-section' => 'App\\Filament\\Resources\\SectionResource\\Pages\\EditSection',
    'app.filament.resources.section-resource.pages.list-sections' => 'App\\Filament\\Resources\\SectionResource\\Pages\\ListSections',
    'app.filament.resources.slider-resource.pages.create-slider' => 'App\\Filament\\Resources\\SliderResource\\Pages\\CreateSlider',
    'app.filament.resources.slider-resource.pages.edit-slider' => 'App\\Filament\\Resources\\SliderResource\\Pages\\EditSlider',
    'app.filament.resources.slider-resource.pages.list-sliders' => 'App\\Filament\\Resources\\SliderResource\\Pages\\ListSliders',
    'app.filament.resources.suggestion-resource.pages.create-suggestion' => 'App\\Filament\\Resources\\SuggestionResource\\Pages\\CreateSuggestion',
    'app.filament.resources.suggestion-resource.pages.edit-suggestion' => 'App\\Filament\\Resources\\SuggestionResource\\Pages\\EditSuggestion',
    'app.filament.resources.suggestion-resource.pages.list-suggestions' => 'App\\Filament\\Resources\\SuggestionResource\\Pages\\ListSuggestions',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\laravel\\digi\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\laravel\\digi\\app\\Filament\\Resources\\BlogResource.php' => 'App\\Filament\\Resources\\BlogResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\CareerCounsellingResource.php' => 'App\\Filament\\Resources\\CareerCounsellingResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\CenterResource.php' => 'App\\Filament\\Resources\\CenterResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\ConsultationResource.php' => 'App\\Filament\\Resources\\ConsultationResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\ContactResource.php' => 'App\\Filament\\Resources\\ContactResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\CourseResource.php' => 'App\\Filament\\Resources\\CourseResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\FreeCounselingResource.php' => 'App\\Filament\\Resources\\FreeCounselingResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\GeneralResource.php' => 'App\\Filament\\Resources\\GeneralResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\PageResource.php' => 'App\\Filament\\Resources\\PageResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\SectionResource.php' => 'App\\Filament\\Resources\\SectionResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\SliderResource.php' => 'App\\Filament\\Resources\\SliderResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\SuggestionResource.php' => 'App\\Filament\\Resources\\SuggestionResource',
    'D:\\laravel\\digi\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\laravel\\digi\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\laravel\\digi\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);