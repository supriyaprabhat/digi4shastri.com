<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\FilamentNavigationServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\ViewServiceProvider::class,
];
